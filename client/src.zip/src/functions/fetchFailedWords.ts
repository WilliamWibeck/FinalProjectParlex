import { getAuth } from "firebase/auth";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  getFirestore,
} from "firebase/firestore";

const db = getFirestore();
const auth = getAuth();

export const fetchFailedWords = async () => {
  const user = auth.currentUser;
  if (!user) return [];

  try {
    const userRef = doc(db, "user_progress", user.uid);
    const userDoc = await getDoc(userRef);

    if (userDoc.exists()) {
      const failedWords = userDoc.data()?.wordsFailed || {};
      const failedWordsIds = Object.keys(failedWords);

      const wordsRef = collection(db, "words");
      const allWordsSnapshot = await getDocs(wordsRef);

      const failedWordsList = allWordsSnapshot.docs
        .filter((doc) => failedWordsIds.includes(doc.id))
        .map((doc) => ({ id: doc.id, ...doc.data() }));

      return failedWordsList;
    } else {
      console.log("No progress data");
      return [];
    }
  } catch {
    console.log("Error fetching failed words");

    return [];
  }
};
