import { getAuth } from "firebase/auth";
import { doc, getDoc, getFirestore } from "firebase/firestore";
import { useEffect } from "react";

const auth = getAuth();
const db = getFirestore();

export const fetchTotalWords = async () => {
  const user = auth.currentUser;
  const [totalWordsTranslated, setTotalWordsTranslated] = useState([]);

  const fetchStats = async () => {
    if (user) {
      try {
        const userRef = doc(db, "user_progress", user.uid);

        console.log("here");
        const snapshot = await getDoc(userRef);
        const snapshotData = snapshot.data();
        const totalWordsDone = snapshotData?.wordsLearned;
        setTotalWordsTranslated(totalWordsDone);
        console.log(totalWordsDone);
      } catch {
        console.log("error");
      }
    }
  };
};
