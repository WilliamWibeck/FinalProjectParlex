import { useState } from "react";
import { collection, doc, addDoc, getDoc, setDoc } from "firebase/firestore";
import { db } from "../../firebase/firebase";
import { Box, Button, Stack, TextField, MenuItem, Select } from "@mui/material";

const WordAddingForm = () => {
  const [french, setFrench] = useState("");
  const [english, setEnglish] = useState("");
  const [example, setExample] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [category, setCategory] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!category || !english || !french || !difficulty || !example) {
      alert("Please fill in all fields.");
      return;
    }

    try {
      const categoryRef = doc(db, "categories", category);

      const categorySnapshot = await getDoc(categoryRef);
      if (!categorySnapshot.exists()) {
        await setDoc(categoryRef, {
          name: category,
          subCollections: ["words"],
          createdAt: new Date(),
        });
        console.log(`New category "${category}" created.`);
      }

      const wordsRef = collection(categoryRef, "words");
      await addDoc(wordsRef, {
        french,
        english,
        example,
        difficulty,
      });

      alert(`Word added successfully to the "${category}" category!`);

      setFrench("");
      setEnglish("");
      setExample("");
      setDifficulty("");
      setCategory("");
    } catch (error) {
      console.error("An error occurred while adding the word:", error);
      alert("Failed to add the word. Please try again.");
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ color: "white" }}>
      <Stack gap={2} marginY={2}>
        <TextField
          sx={{ color: "white" }}
          label="Word in French"
          type="text"
          value={french}
          onChange={(e) => setFrench(e.target.value)}
          required
        />
        <TextField
          sx={{ "& .MuiOutlinedInput-input": { color: "white" } }}
          label="Word in English"
          type="text"
          value={english}
          onChange={(e) => setEnglish(e.target.value)}
          required
        />
        <TextField
          sx={{ "& .MuiOutlinedInput-input": { color: "white" } }}
          label="Example Sentence"
          type="text"
          value={example}
          onChange={(e) => setExample(e.target.value)}
          required
        />
        <TextField
          sx={{ "& .MuiOutlinedInput-input": { color: "white" } }}
          label="Category"
          type="text"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          required
        />
        <Select
          value={difficulty}
          onChange={(e) => setDifficulty(e.target.value)}
          displayEmpty
          sx={{ "& .MuiOutlinedInput-input": { color: "white" } }}
          required
        >
          <MenuItem disabled value="">
            <em>Select Difficulty</em>
          </MenuItem>
          <MenuItem value="easy">Easy</MenuItem>
          <MenuItem value="medium">Medium</MenuItem>
          <MenuItem value="hard">Hard</MenuItem>
        </Select>
      </Stack>
      <Button
        type="submit"
        variant="contained"
        sx={{ marginTop: 2, backgroundColor: "white", color: "black" }}
      >
        Add Word
      </Button>
    </Box>
  );
};

export default WordAddingForm;
