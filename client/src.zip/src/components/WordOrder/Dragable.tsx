import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Card } from "@mui/material";

const Dragable = ({ id, word }) => {
  const { attributes, listeners, setNodeRef, transform, transition } =
    useSortable({ id });

  return (
    <Card
      ref={setNodeRef}
      sx={{
        transform: CSS.Transform.toString(transform),
        transition,
        padding: "10px 20px",
        margin: "5px 0",
        background: "lightblue",
        borderRadius: "5px",
        textAlign: "center",
        cursor: "grab",
        marginX: 2,
        height: "50px",
        width: "80px",
      }}
      {...attributes}
      {...listeners}
    >
      {word}
    </Card>
  );
};

export default Dragable;
