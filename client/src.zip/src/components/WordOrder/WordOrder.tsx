import { Box, Button } from "@mui/material";
import { DndContext } from "@dnd-kit/core";
import { arrayMove, SortableContext } from "@dnd-kit/sortable";
import { getAuth } from "firebase/auth";
import { collection, getDocs, getFirestore } from "firebase/firestore";
import { useEffect, useState } from "react";
import Dragable from "./Dragable";
import { incrementWordOrder } from "../../functions/incrementWordOrder";
import Sidebar from "../Sidebar/Sidebar";

const db = getFirestore();

const WordOrder = () => {
  const [sentences, setSentences] = useState([]);
  const [randomSentence, setRandomSentence] = useState();
  const [formattedSentence, setFormattedSentence] = useState([]);
  const [shuffledWords, setShuffledWords] = useState([]);

  const sentencesRef = collection(db, "sentences");

  const fetchSentences = async () => {
    try {
      const snapshot = await getDocs(sentencesRef);
      const sentences = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSentences(sentences);
    } catch (error) {
      console.log("Error fetching sentences:", error);
    }
  };

  const fetchRandomSentence = () => {
    if (sentences.length > 0) {
      const randomIndex = Math.floor(Math.random() * sentences.length);
      const random = sentences[randomIndex];
      setRandomSentence(random);

      const formatted = random.sentence.split(" ");
      setFormattedSentence(formatted);

      const shuffled = [...formatted].sort(() => Math.random() - 0.5);
      setShuffledWords(shuffled);
    }
  };

  const handleDrag = (e) => {
    const { active, over } = e;

    if (active.id !== over?.id) {
      const startIndex = shuffledWords.indexOf(active.id);
      const endIndex = shuffledWords.indexOf(over.id);

      setShuffledWords((prevWords) =>
        arrayMove(prevWords, startIndex, endIndex)
      );
    }
  };

  const validateOrder = () => {
    if (shuffledWords.join(" ") === formattedSentence.join(" ")) {
      alert("Success!!");
      incrementWordOrder();
      fetchRandomSentence();
    } else {
      alert("Wrong answer :/");
    }
  };

  useEffect(() => {
    fetchSentences();
  }, []);

  useEffect(() => {
    if (sentences.length > 0) {
      fetchRandomSentence();
    }
  }, [sentences]);

  return (
    <Box
      sx={{
        height: "100vh",
        width: "100vw",
        display: "flex",
        flexDirection: "row",
      }}
    >
      <Sidebar />
      {randomSentence ? (
        <DndContext onDragEnd={handleDrag}>
          <SortableContext items={shuffledWords}>
            {shuffledWords.map((word) => (
              <Dragable id={word} key={word} word={word} />
            ))}
          </SortableContext>
        </DndContext>
      ) : (
        "Loading..."
      )}
      <Button onClick={validateOrder}>Validate answer :^)</Button>
    </Box>
  );
};

export default WordOrder;
