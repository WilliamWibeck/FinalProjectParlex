import {
  Box,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Toolbar,
} from "@mui/material";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { logout } from "../../firebase/auth";

const drawerWidthExpanded = 240;
const drawerWidthCollapsed = 80;

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(true);
  const [open, setOpen] = useState(true);
  const toggleDrawer = () => {
    setCollapsed(!collapsed);
  };

  const handleClick = () => {
    setOpen(!open);
  };

  return (
    <Box
      sx={{
        display: "flex",
        margin: "16px 0",
        height: "calc(100% - 32px)",
        color: "white",
        backgroundColor: "rgba(202, 202, 202, 0.25)",
        borderRadius: "10px",

        backdropFilter: "blur(8.5)px",
        WebkitBackdropFilter: "blur(8.5)px",
      }}
    >
      <Drawer
        variant="permanent"
        sx={{
          width: collapsed ? drawerWidthCollapsed : drawerWidthExpanded,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: collapsed ? drawerWidthCollapsed : drawerWidthExpanded,
            transition: "width 0.5s ease",
            overflowX: "hidden",
            boxSizing: "border-box",
            color: "white",
            backgroundColor: "rgba(202, 202, 202, 0.25)",
            borderRadius: "10px",

            backdropFilter: "blur(8.5)px",
            WebkitBackdropFilter: "blur(8.5)px",
            margin: 1,
            height: "calc(100% - 16px)",
          },
        }}
      >
        <Toolbar
          sx={{
            display: "flex",
            justifyContent: collapsed ? "center" : "flex-end",
          }}
        >
          {!collapsed && "Parlex"}
          <IconButton onClick={toggleDrawer}>[ ]</IconButton>
        </Toolbar>
        <Divider />
        <List>
          <ListItem>
            <ListItemButton component={Link} to="/dashboard">
              <ListItemText primary="Dashboard" />
            </ListItemButton>
          </ListItem>
          <ListItem>
            <ListItemButton component={Link} to="/admin">
              <ListItemText primary="Admin" />
            </ListItemButton>
          </ListItem>
          <ListItem>
            <ListItemButton>
              <ListItemText primary="Leaderboards" />
            </ListItemButton>
          </ListItem>
          <ListItem>
            <ListItemButton component={Link} to="/flashcards">
              <ListItemText primary="Flashcards" />
            </ListItemButton>
          </ListItem>

          <ListItem>
            <ListItemButton onClick={logout}>
              <ListItemText primary="Logout" />
            </ListItemButton>
          </ListItem>
        </List>
      </Drawer>
    </Box>
  );
};

export default Sidebar;
