import { Divider, Stack, Typography } from "@mui/material";
import React from "react";

type Props = {};

const Statbar = (props: Props) => {
  return (
    <Stack
      direction="row"
      sx={{
        color: "white",
        backgroundColor: "rgba(202, 202, 202, 0.25)",
        borderRadius: "10px",

        backdropFilter: "blur(8.5)px",
        WebkitBackdropFilter: "blur(8.5)px",
        padding: 1,
      }}
    >
      <Typography>Words done this week: 74</Typography>
      <Divider variant="middle" />
      <Typography>Most practised category: Animals</Typography>
      <Divider variant="middle" />
      <Typography>Time spent this week: 884 minutes</Typography>
    </Stack>
  );
};

export default Statbar;
