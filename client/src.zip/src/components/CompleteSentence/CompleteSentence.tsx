import { Box, Button, TextField, Typography } from "@mui/material";
import { getAuth } from "firebase/auth";
import { collection, doc, getDocs, getFirestore } from "firebase/firestore";
import { useEffect, useState } from "react";
import { incrementSentencesLearned } from "../../functions/incrementSentencesLearned";

type Props = {};

const db = getFirestore();

const CompleteSentence = (props: Props) => {
  const [sentenceAnswer, setSentenceAnswer] = useState("");
  const [sentences, setSentences] = useState([]);
  const [formattedSentence, setFormattedSentence] = useState("");
  const [randomSentence, setRandomSentence] = useState(null);
  const auth = getAuth();
  const user = auth.currentUser;

  const sentencesRef = collection(db, "sentences");

  const fetchSentences = async () => {
    try {
      const snapshot = await getDocs(sentencesRef);
      const sentences = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSentences(sentences);
    } catch (error) {
      console.log("Error fetching sentences:", error);
    }
  };

  const fetchRandomSentence = () => {
    if (sentences.length > 0) {
      const randomIndex = Math.floor(Math.random() * sentences.length);
      const random = sentences[randomIndex];
      setRandomSentence(random);
      const formatted = random.sentence.split(/\b(?:un|une)\b/).join("___");
      setFormattedSentence(formatted);
    }
  };

  const CheckAnswer = (e) => {
    e.preventDefault();
    if (sentenceAnswer.trim() === randomSentence.sentence.trim()) {
      alert("Correct!");
      incrementSentencesLearned();
      fetchRandomSentence();
    } else {
      alert(`Wrong! The correct sentence is: ${randomSentence.sentence}`);
    }
  };

  useEffect(() => {
    fetchSentences();
  }, []);

  useEffect(() => {
    if (sentences.length > 0) {
      fetchRandomSentence();
    }
  }, [sentences]);

  return (
    <Box>
      <Typography sx={{ color: "white", marginBottom: 2 }}>
        {formattedSentence}
      </Typography>

      <form onSubmit={CheckAnswer}>
        <TextField
          value={sentenceAnswer}
          onChange={(e) => setSentenceAnswer(e.target.value)}
          placeholder="Fill in the blank"
          sx={{
            "& .MuiOutlinedInput-root": {
              "& input": {
                color: "white",
              },
            },
          }}
        />
        <Button type="submit" variant="contained">
          Submit Answer
        </Button>
      </form>

      <Button
        onClick={fetchRandomSentence}
        variant="outlined"
        sx={{ marginTop: 2 }}
      >
        Get New Random Sentence
      </Button>
    </Box>
  );
};

export default CompleteSentence;
