import { Card, Paper, Typography } from "@mui/material";

interface StatBoxProps {
  wordStat: string | null | undefined;
}

const StatBox = ({ wordStat }: StatBoxProps) => {
  return (
    <Paper
      sx={{
        height: "200px",
        width: "200px",
        marginY: "20px",
        color: "white",
        backgroundColor: "rgba(202, 202, 202, 0.25)",
        borderRadius: "10px",

        backdropFilter: "blur(8.5)px",
        WebkitBackdropFilter: "blur(8.5)px",
      }}
    >
      <Card
        sx={{
          height: "100%",
          width: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "rgba(202, 202, 202, 0.25)",
        }}
      >
        <Typography>{wordStat}</Typography>
      </Card>
    </Paper>
  );
};

export default StatBox;
