import { Box, Button, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ReactTyped } from "react-typed";

const IntroPage = ({ handleIntroShown }) => {
  const [introShown, setIntroShown] = useState(false);
  const [buttonVisible, setButtonVisible] = useState(false);
  const [boxVisible, setBoxVisible] = useState(true);

  const navigate = useNavigate();

  const handleIntro = () => {
    setIntroShown(true);
    handleIntroShown(true);
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setButtonVisible(true);
    }, 4000);

    return () => clearTimeout(timer);
  }, []);

  const handleNavigate = () => {
    setBoxVisible(false);

    setTimeout(() => {
      handleIntro();
    }, 2000);
  };

  return (
    <Box
      sx={{
        height: "100vh",
        width: "100vw",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        opacity: boxVisible ? 1 : 0,
        transition: "opacity 1s ease-in",
      }}
    >
      <Box
        sx={{
          fontSize: "5rem",
          color: "white",
          display: "flex",
          flexDirection: "column",
          gap: 10,
        }}
      >
        <ReactTyped strings={["Welcome to Parlex"]} typeSpeed={100} />
      </Box>
      <Button
        sx={{
          opacity: buttonVisible ? 1 : 0,
          transition: "opacity 1s ease-in",
        }}
        onClick={handleNavigate}
      >
        Get Started
      </Button>
    </Box>
  );
};

export default IntroPage;
