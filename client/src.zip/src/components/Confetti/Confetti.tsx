import Confetti from "react-confetti";

const Confetti = () => {
  return <Confetti />;
};

export default Confetti;
