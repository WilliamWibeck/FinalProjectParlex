import { collection, getDocs, addDoc, doc, setDoc } from "firebase/firestore";
import { db } from "../../firebase/firebase";
import WordAddingForm from "../WordAddingForm/WordAddingForm";
import { useEffect, useState } from "react";
import { Typography, Select, MenuItem, Button, Box } from "@mui/material";
import WordGrid from "../WordGrid/WordGrid";
import Sidebar from "../Sidebar/Sidebar";

const AdminPage = () => {
  const [words, setWords] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [categories, setCategories] = useState([]);

  // Fetch words for a selected category
  const getWords = async (category: string) => {
    try {
      const wordsRef = collection(db, "categories", category, "words");
      const querySnapshot = await getDocs(wordsRef);
      const results = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        category: category,
      }));
      setWords(results);
      console.log("Fetched Words:", results);
    } catch (error) {
      console.error("Error fetching words:", error);
    }
  };

  // Fetch categories
  const getCategories = async () => {
    try {
      const categoriesRef = collection(db, "categories");
      const querySnapshot = await getDocs(categoriesRef);
      const categoryList = querySnapshot.docs.map((doc) => doc.id);
      setCategories(categoryList);
      console.log("Fetched Categories:", categoryList);

      // Automatically select the first category
      if (categoryList.length > 0 && !selectedCategory) {
        setSelectedCategory(categoryList[0]);
        getWords(categoryList[0]);
      }
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  // Handle JSON import for words
  const handleJSONImport = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const data = JSON.parse(e.target?.result as string);
          for (const item of data) {
            if (!item.category || !item.english || !item.french) continue;

            const categoryRef = doc(db, "categories", item.category);
            await setDoc(categoryRef, {}, { merge: true });

            const wordsRef = collection(categoryRef, "words");
            await addDoc(wordsRef, {
              english: item.english,
              french: item.french,
              example: item.example,
              difficulty: item.difficulty,
            });
          }
          alert("Words successfully uploaded!");
          getWords(selectedCategory);
        } catch (error) {
          console.error("Error parsing JSON:", error);
          alert("Error parsing the JSON file.");
        }
      };
      reader.readAsText(file);
    }
  };

  // Handle JSON import for sentences
  const importJSONsentences = async (event) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();

      reader.onload = async (e) => {
        try {
          const data = JSON.parse(e.target.result);
          if (!Array.isArray(data)) {
            console.error("Invalid JSON format: Expected an array.");
            return;
          }

          const sentencesCollection = collection(db, "sentences");
          console.log("Uploading sentences...");

          for (const item of data) {
            if (!item.sentence || !item.category) {
              console.warn("Skipping invalid item:", item);
              continue;
            }

            await addDoc(sentencesCollection, {
              sentence: item.sentence,
              category: item.category,
            });
            console.log(`Uploaded: ${item.sentence}`);
          }

          alert("Sentences uploaded successfully!");
        } catch (error) {
          console.error("Error parsing or uploading JSON:", error);
        }
      };

      reader.readAsText(file);
    }
  };

  // Load categories on component mount
  useEffect(() => {
    getCategories();
  }, []);

  return (
    <Box sx={{ display: "flex", flexDirection: "row", margin: 4 }}>
      <Sidebar />
      <div>
        <Typography variant="h4">Admin Page</Typography>
        <div style={{ marginBottom: "1rem" }}>
          <Select
            value={selectedCategory}
            onChange={(e) => {
              setSelectedCategory(e.target.value);
              getWords(e.target.value);
            }}
          >
            {categories.map((category) => (
              <MenuItem key={category} value={category}>
                {category}
              </MenuItem>
            ))}
          </Select>
          <Button
            onClick={() => getWords(selectedCategory)}
            variant="contained"
            style={{
              marginLeft: "1rem",
              backgroundColor: "white",
              color: "black",
            }}
          >
            Load Words
          </Button>
        </div>
        <WordAddingForm />
        <WordGrid rows={words} />
        <Typography variant="h6" style={{ marginTop: "2rem" }}>
          Import Words from JSON
        </Typography>
        <input type="file" accept=".json" onChange={handleJSONImport} />
        <Typography variant="h6" style={{ marginTop: "2rem" }}>
          Import Sentences from JSON
        </Typography>
        <input type="file" accept=".json" onChange={importJSONsentences} />
      </div>
    </Box>
  );
};

export default AdminPage;
