import { useEffect, useState } from "react";
import {
  Typography,
  Paper,
  TextField,
  Button,
  Stack,
  Box,
} from "@mui/material";
import { NavLink } from "react-router-dom";
import { incrementWordsLearned } from "../../functions/incrementWordsLearned";
import { trackFailedWord } from "../../functions/trackFailedWord";
import { doc, getFirestore, increment, updateDoc } from "firebase/firestore";
import { getAuth } from "firebase/auth";

interface FlashCardProps {
  category: string | null;
  words: { id: string; french: string; english: string; example?: string }[];
  setCategoryChoosen: boolean;
}

const FlashCard = ({ category, words, setCategoryChoosen }: FlashCardProps) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userGuess, setUserGuess] = useState("");
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [timeSpent, setTimeSpent] = useState<number>(0);

  const auth = getAuth();
  const user = auth.currentUser;

  const userId = user?.uid;

  useEffect(() => {
    const start = new Date();
    setStartTime(start);

    const interval = setInterval(() => {
      const now = new Date();
      setTimeSpent((now.getTime() - start.getTime()) / 1000); // Update time spent
    }, 1000);

    return () => {
      clearInterval(interval);
      const end = new Date();
      if (startTime) {
        const timeDiff = (end.getTime() - start.getTime()) / 1000;
        saveTimeSpentToDB(userId, timeDiff);
      }
    };
  }, []);

  const saveTimeSpentToDB = async (userId: string, timeSpent: number) => {
    const db = getFirestore();
    const userRef = doc(db, "user_progress", userId);

    await updateDoc(userRef, {
      timeSpent: increment(timeSpent),
    });
  };

  const currentWord = words[currentIndex];

  const handleCheckAnswer = async () => {
    if (isAnswered) return;

    if (userGuess.trim().toLowerCase() === currentWord.french.toLowerCase()) {
      await incrementWordsLearned();
      setFeedback("Correct! 🎉 Your progress has been updated.");
    } else {
      trackFailedWord(currentWord.id);
      setFeedback(`Incorrect. The correct answer is: ${currentWord.french}`);
    }

    setIsAnswered(true);
  };

  const handleNextWord = () => {
    setFeedback(null);
    setUserGuess("");
    setIsAnswered(false);
    setCurrentIndex((prevIndex) => (prevIndex + 1) % words.length);
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <p style={{ color: "white" }}>{Math.round(timeSpent)}</p>
      <Paper sx={{ p: 4, textAlign: "center" }}>
        <Typography variant="h4" gutterBottom>
          Guess the French Word
        </Typography>
        <Typography variant="h5" sx={{ mb: 2 }}>
          Category: {category || "Unknown"}
        </Typography>

        {words.length > 0 ? (
          <>
            <Typography variant="h6" sx={{ mb: 2 }}>
              What is the French translation for:{" "}
              <strong style={{ color: "#1976d2" }}>
                {currentWord.english}
              </strong>
              ?
            </Typography>

            <Stack
              direction="row"
              spacing={2}
              justifyContent="center"
              sx={{ mb: 2 }}
            >
              <TextField
                label="Your Guess"
                variant="outlined"
                value={userGuess}
                onChange={(e) => setUserGuess(e.target.value)}
                disabled={isAnswered}
              />
              <Button
                variant="contained"
                color="primary"
                onClick={handleCheckAnswer}
                disabled={isAnswered}
              >
                Check
              </Button>
            </Stack>

            {feedback && (
              <Typography
                variant="body1"
                sx={{
                  color: feedback.startsWith("Correct") ? "green" : "red",
                  mb: 2,
                }}
              >
                {feedback}
              </Typography>
            )}

            <Stack direction="row" spacing={2} justifyContent="center">
              <Button
                variant="contained"
                color="secondary"
                onClick={handleNextWord}
                disabled={!isAnswered}
              >
                Next Word
              </Button>
              <Button component={NavLink} variant="outlined" color="primary">
                Back to Categories
              </Button>
            </Stack>
          </>
        ) : (
          <Typography variant="body1">
            No words available for this category.
          </Typography>
        )}
      </Paper>
    </Box>
  );
};

export default FlashCard;
