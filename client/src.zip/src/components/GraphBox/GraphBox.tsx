import { Box, Button, easing } from "@mui/material";
import { LineChart } from "@mui/x-charts/LineChart";
import { getAuth } from "firebase/auth";
import { doc, getDoc, getFirestore } from "firebase/firestore";
import { useEffect, useState } from "react";

type Props = {};

const auth = getAuth();
const db = getFirestore();

const GraphBox = (props: Props) => {
  const user = auth.currentUser;
  const [wordsByDateArray, setWordsByDateArray] = useState([]);
  const [sentencesByDateArray, setSentencesByDateArray] = useState([]);

  const getsnapshot = async () => {
    if (user) {
      const userRef = doc(db, "user_progress", user.uid);

      const snapshot = await getDoc(userRef);
      const snapshotdata = snapshot.data();
      const wordsByDate = snapshotdata?.wordsByDate;
      const sentencesByDate = snapshotdata?.sentencesByDate;

      const sentencesArray = Object.entries(sentencesByDate).map(
        ([date, sentencesDone]) => ({
          date,
          sentencesDone: Number(sentencesDone),
        })
      );
      setSentencesByDateArray(sentencesArray);
      const wordsArray = Object.entries(wordsByDate).map(
        ([date, wordsDone]) => ({
          date,
          wordsDone: Number(wordsDone),
        })
      );
      setWordsByDateArray(wordsArray);
    }
  };

  useEffect(() => {
    getsnapshot();
  }, []);

  return (
    <Box
      sx={{
        color: "white",
        backgroundColor: "rgba(202, 202, 202, 0.25)",
        borderRadius: "10px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <LineChart
        xAxis={[{ dataKey: "date", label: "" }]}
        series={[
          {
            dataKey: "wordsDone",
            label: "Words done",
            color: "yellow",
          },
        ]}
        dataset={wordsByDateArray}
        width={500}
        height={300}
        sx={{
          width: "100%",
          "& .MuiChart-line": { strokeWidth: 2 },
          "& .MuiChart-grid": { display: "none" },
          "& .MuiChart-marker": { display: "none" },
          "&:hover .MuiChart-marker": {
            display: "block",
          },
        }}
      />
    </Box>
  );
};

export default GraphBox;
