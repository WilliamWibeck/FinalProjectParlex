import { FormEvent, useState } from "react";
import { Alert, Box, Button, Divider, Paper, TextField } from "@mui/material";
import { signup } from "../../firebase/auth";
import eiffelTower from "../../assets/eiffel1.jpg";
import IntroPage from "../IntroPage/IntroPage";
import { useNavigate } from "react-router-dom";
import { useReward } from "react-rewards";

type Props = {};

const Signup = (props: Props) => {
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [introShown, setIntroShown] = useState(false);
  const [alertVisible, setAlertVisible] = useState(false);

  const navigate = useNavigate();

  const toggleAlert = () => {
    setAlertVisible(true);
  };

  const { reward: confettiReward } = useReward("confettiReward", "confetti");
  const handleSignup = async (e: FormEvent) => {
    e.preventDefault();
    setError("");

    try {
      await signup({ email, password, firstName, lastName });
      confettiReward();
      toggleAlert();
      setTimeout(() => {
        navigate("/dashboard");
      }, 2000);
    } catch {
      alert("error");
    }
  };
  const handleIntroState = (value) => {
    setIntroShown(true);
  };
  return (
    <Box
      sx={{
        height: "100vh",
        width: "100vw",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        gap: 5,
      }}
    >
      {!introShown ? (
        <IntroPage handleIntroShown={handleIntroState} />
      ) : (
        <Paper
          sx={{
            backgroundColor: "background.paper",
            display: "flex",
            flexDirection: "row",
            width: "30vh",
            height: "40vh",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <span
            id="confettiReward"
            style={{ position: "absolute", left: "center" }}
          ></span>
          <Box
            sx={{
              width: "90%",
              margin: 5,
              display: "flex",
              justifyContent: "center",
              flexDirection: "column",
            }}
          >
            <h1>Create an account.</h1>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                maxWidth: "600px",
              }}
            >
              <form onSubmit={handleSignup}>
                <Box sx={{ display: "flex", flexDirection: "row", gap: 2 }}>
                  <TextField
                    placeholder="First name"
                    onChange={(e) => setFirstName(e.target.value)}
                  ></TextField>
                  <TextField
                    placeholder="Last name"
                    onChange={(e) => setLastName(e.target.value)}
                  ></TextField>
                </Box>
                <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                  <TextField
                    placeholder="Email"
                    onChange={(e) => setEmail(e.target.value)}
                  ></TextField>
                  <TextField
                    placeholder="Password"
                    type="password"
                    onChange={(e) => setPassword(e.target.value)}
                  ></TextField>
                  <Button variant="outlined" type="submit">
                    Create account
                  </Button>
                </Box>
                Already have an account?
              </form>
            </Box>
          </Box>
        </Paper>
      )}
      {alertVisible && (
        <Alert severity="success">Successfully registered account!</Alert>
      )}
    </Box>
  );
};

export default Signup;
