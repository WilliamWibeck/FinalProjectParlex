import { getAuth } from "firebase/auth";
import Box from "@mui/material/Box";
import Sidebar from "../Sidebar/Sidebar";
import Statbar from "../StatBar/Statbar";
import GraphBox from "../GraphBox/GraphBox";
import StatBox from "../StatBox/StatBox";
import CurrentUserChip from "../CurrentUserChip/CurrentUserChip";
import { useEffect, useState } from "react";
import { fetchMostUsedCategory } from "../../functions/fetchMostUsedCategory";
import { doc, getDoc, getFirestore } from "firebase/firestore";
import BlurryBackground from "../BlurryShapesBackground/BlurryBackground";

const auth = getAuth();
const db = getFirestore();

interface Dashboard {
  wordStat: string;
}

const Dashboard = () => {
  const user = auth.currentUser;
  const [mostPractisedCategory, setMostPractisedCategory] = useState<
    string | null | undefined
  >();
  const [totalWordsTranslated, setTotalWordsTranslated] = useState();

  useEffect(() => {
    const fetchMostPractisedCategory = async () => {
      const category = await fetchMostUsedCategory();
      setMostPractisedCategory(category);
      console.log(category);
    };
    fetchMostPractisedCategory();
    fetchTotalWordsTranslated();
  }, []);

  const fetchTotalWordsTranslated = async () => {
    if (user) {
      try {
        const userRef = doc(db, "user_progress", user.uid);

        const snapshot = await getDoc(userRef);
        const snapshotData = snapshot.data();
        const totalWordsDone = snapshotData?.wordsLearned;
        setTotalWordsTranslated(totalWordsDone);
        console.log(totalWordsDone);
      } catch {
        console.log("error");
      }
    }
  };

  return (
    <Box
      sx={{
        position: "relative",
        height: "100vh",
        width: "100vw",
        overflow: "hidden",
      }}
    >
      <Box
        sx={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          zIndex: 0,
        }}
      ></Box>
      <Box
        sx={{
          position: "relative",
          zIndex: 1,
          display: "flex",
          flexDirection: "row",
          gap: "2rem",
          padding: "2rem",
        }}
      >
        <Sidebar />
        <Box
          sx={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            gap: "2rem",
          }}
        >
          <CurrentUserChip />
          <Box sx={{ display: "flex", flexDirection: "row", gap: "5%" }}>
            <StatBox wordStat={mostPractisedCategory} />
            <StatBox wordStat={totalWordsTranslated} />
          </Box>
          <Statbar />
          <GraphBox />
        </Box>
      </Box>
    </Box>
  );
};

export default Dashboard;
