import { Button, Paper, Stack, Typography } from "@mui/material";
import { db, app } from "../../firebase/firebase";
import { collection, getDocs, getFirestore } from "firebase/firestore";
import { useEffect, useState } from "react";
import { fetchWords } from "../../functions/fetchWords";
import { incrementCategoryCount } from "../../functions/incrementCategoryCount";
interface GameFilterProps {
  onCategorySelect: (category: string) => void;
}

const GameFilter = ({ onCategorySelect }: GameFilterProps) => {
  const [categories, setCategories] = useState<string[]>([]);
  const [words, setWords] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const fetchCategories = async () => {
    try {
      const categoriesRef = collection(db, "categories");
      const snapshot = await getDocs(categoriesRef);
      const categoryNames = snapshot.docs.map((doc) => doc.id);
      setCategories(categoryNames);
    } catch {
      alert("Error fetching categories");
    }
  };

  const handleFetchWords = async (category: string) => {
    try {
      const wordsData = await fetchWords(category, "words");
      setWords(wordsData);
      setSelectedCategory(category);
      incrementCategoryCount(category);
    } catch {
      alert("Error fetching words for selected category");
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  return (
    <Stack spacing={2} sx={{ p: 2 }}>
      <Typography variant="h5">Select a Category</Typography>
      {categories.map((category) => (
        <Button
          key={category}
          variant="contained"
          color="primary"
          onClick={() => {
            onCategorySelect(category);
            incrementCategoryCount(category);
          }}
        >
          {category}
        </Button>
      ))}
    </Stack>
  );
};

export default GameFilter;
